#ifndef _POINT_H_
#define _POINT_H_

// based on examples originally by Steve Gribble (UW)

class Point {
public:
	Point(const int x, const int y, const int z);  // constructor
	
	int get_x() const { return x_; }  // inline member function
	int get_y() const { return y_; }  // inline member function
	int get_z() const { return z_; }  // inline member function

	double Distance(const Point &other) const;  // member function

 private:
  int x_;  // data member
  int y_;  // data member
  int z_;  // data member

};  // class Point

#endif  // _POINT_H_

